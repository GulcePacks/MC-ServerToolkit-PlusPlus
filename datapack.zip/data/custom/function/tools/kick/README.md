## Bu dosyalar, Minecraft 1.20.2 ve üzeri sürümlerde gelen Command Macros özelliğini kullanarak profesyonel ve renkli ceza mesajları oluşturmanıza olanak tanır. Herhangi bir plugin (Eklenti) gerektirmeden, tamamen Vanilla sistemler üzerinde çalışır.

# ✨ Özellikler
- Görsel Tasarım: Standart ve sıkıcı ban mesajları yerine renkli, sembollü ve düzenli bir ekran.

- Dinamik Veri: Tarih, saat, yetkili ve sebep gibi bilgiler makrolar aracılığıyla otomatik işlenir.

- Performans Dostu: Plugin yükü bindirmez, tamamen Minecraft'ın kendi fonksiyon sistemini kullanır.
